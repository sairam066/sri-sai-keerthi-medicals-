const phone='917013047415';let cart={};
const $=s=>document.querySelector(s);
$('#year').textContent=new Date().getFullYear();
$('#menu').addEventListener('click',()=>$('#nav').classList.toggle('open'));
document.querySelectorAll('.filters button').forEach(btn=>btn.addEventListener('click',()=>{document.querySelectorAll('.filters button').forEach(b=>b.classList.remove('active'));btn.classList.add('active');document.querySelectorAll('.products article').forEach(card=>card.classList.toggle('hide',btn.dataset.filter!=='all'&&card.dataset.kind!==btn.dataset.filter));}));
function render(){let total=Object.values(cart).reduce((a,b)=>a+b,0);$('#count').textContent=total;$('#send').disabled=!total;$('#cartItems').innerHTML=total?Object.entries(cart).map(([name,n])=>`<div class="cart-row"><strong>${name}</strong><span><button data-minus="${name}">−</button><b class="qty">${n}</b><button data-plus="${name}">+</button></span></div>`).join(''):'No items added yet.';}
document.addEventListener('click',e=>{if(e.target.matches('.add')){let n=e.target.dataset.name;cart[n]=(cart[n]||0)+1;render();}if(e.target.dataset.plus){cart[e.target.dataset.plus]++;render();}if(e.target.dataset.minus){let n=e.target.dataset.minus;cart[n]--;if(cart[n]<=0)delete cart[n];render();}});
$('#clear').addEventListener('click',()=>{cart={};render();});
$('#send').addEventListener('click',()=>{let lines=Object.entries(cart).map(([n,q])=>`${n} x ${q}`).join('%0A');window.open(`https://wa.me/${phone}?text=Hello%2C%20I%20would%20like%20to%20enquire%20about%3A%0A${encodeURIComponent(lines)}`,'_blank');});
render();